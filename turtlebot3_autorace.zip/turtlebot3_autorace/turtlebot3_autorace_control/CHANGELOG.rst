^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot3_autorace_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.0 (2018-05-30)
------------------
* modified system configuration related with the .py extensions & core launch launches
* merged pull request `#4 <https://github.com/ROBOTIS-GIT/turtlebot3_autorace/issues/4>`_ `#3 <https://github.com/ROBOTIS-GIT/turtlebot3_autorace/issues/3>`_ `#2 <https://github.com/ROBOTIS-GIT/turtlebot3_autorace/issues/2>`_ 
* Contributors: Leon Jung, Pyo

1.0.0 (2018-03-20)
------------------
* refactoring to release
* fixed the dependencies
* updated control_parking.py
* first upload of turtlebot3_autorace
* Contributors: Leon Jung, Pyo
